<?php

/**
 * @file
 * Script to migrate field_organizer values to field_event_vendor.
 *
 * Usage: ddev drush php:script web/modules/custom/myeventlane_event/scripts/migrate_organizer_to_vendor.php
 *
 * This script:
 * 1. Finds events with field_organizer but no field_event_vendor
 * 2. Attempts to find or create a vendor for the organizer user
 * 3. Sets field_event_vendor on the event
 * 4. Removes field_organizer value
 *
 * WARNING: This is a data migration. Backup database first.
 */

use Drupal\node\Entity\Node;
use Drupal\user\Entity\User;

echo "Starting organizer to vendor migration...\n\n";

$storage = \Drupal::entityTypeManager()->getStorage('node');
$query = $storage->getQuery()
  ->accessCheck(FALSE)
  ->condition('type', 'event')
  ->exists('field_organizer')
  ->execute();

if (empty($query)) {
  echo "No events with field_organizer found.\n";
  exit(0);
}

$events = $storage->loadMultiple($query);
echo "Found " . count($events) . " events with field_organizer.\n\n";

$vendor_storage = \Drupal::entityTypeManager()->getStorage('myeventlane_vendor');
$migrated = 0;
$skipped = 0;
$errors = 0;

foreach ($events as $event) {
  echo "Processing event: {$event->label()} (ID: {$event->id()})\n";
  
  // Check if already has vendor.
  if ($event->hasField('field_event_vendor') && !$event->get('field_event_vendor')->isEmpty()) {
    echo "  - Already has vendor, skipping.\n";
    $skipped++;
    continue;
  }
  
  // Get organizer user.
  if (!$event->hasField('field_organizer') || $event->get('field_organizer')->isEmpty()) {
    echo "  - No organizer value, skipping.\n";
    $skipped++;
    continue;
  }
  
  $organizer_id = $event->get('field_organizer')->target_id;
  if (!$organizer_id) {
    echo "  - Invalid organizer value, skipping.\n";
    $skipped++;
    continue;
  }
  
  $organizer = User::load($organizer_id);
  if (!$organizer) {
    echo "  - Organizer user not found (ID: $organizer_id), skipping.\n";
    $errors++;
    continue;
  }
  
  echo "  - Organizer: {$organizer->getDisplayName()} (UID: $organizer_id)\n";
  
  // Try to find existing vendor for this user.
  $vendor_query = $vendor_storage->getQuery()
    ->accessCheck(FALSE)
    ->condition('uid', $organizer_id)
    ->range(0, 1)
    ->execute();
  
  $vendor = NULL;
  if (!empty($vendor_query)) {
    $vendor = $vendor_storage->load(reset($vendor_query));
    echo "  - Found existing vendor: {$vendor->label()} (ID: {$vendor->id()})\n";
  } else {
    echo "  - No vendor found for user. Creating vendor...\n";
    // Create vendor for user.
    $vendor = $vendor_storage->create([
      'name' => $organizer->getDisplayName() . "'s Events",
      'uid' => $organizer_id,
    ]);
    $vendor->save();
    echo "  - Created vendor: {$vendor->label()} (ID: {$vendor->id()})\n";
  }
  
  // Set vendor on event.
  if ($event->hasField('field_event_vendor')) {
    $event->set('field_event_vendor', $vendor->id());
    $event->save();
    echo "  - ✓ Set vendor on event.\n";
    $migrated++;
  } else {
    echo "  - ERROR: Event does not have field_event_vendor field.\n";
    $errors++;
  }
  
  echo "\n";
}

echo "Migration complete.\n";
echo "  - Migrated: $migrated\n";
echo "  - Skipped: $skipped\n";
echo "  - Errors: $errors\n";
echo "\n";
echo "After verification, you can remove field_organizer using:\n";
echo "  ddev drush php:script web/modules/custom/myeventlane_event/scripts/remove_unused_fields.php\n";
