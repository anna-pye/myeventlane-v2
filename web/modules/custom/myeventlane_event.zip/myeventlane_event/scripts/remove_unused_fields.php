<?php

/**
 * @file
 * Script to remove unused/redundant Event node fields.
 *
 * Usage: ddev drush php:script web/modules/custom/myeventlane_event/scripts/remove_unused_fields.php
 *
 * This script removes:
 * - field_event_location (string) - Redundant with field_location (address)
 * - field_rsvp_target (node reference) - Purpose unclear, unused
 * - field_organizer (user reference) - Redundant with vendor->uid
 *
 * WARNING: This is a destructive operation. Backup database first.
 */

use Drupal\field\Entity\FieldConfig;
use Drupal\field\Entity\FieldStorageConfig;

// Fields to remove.
$fields_to_remove = [
  'field_event_location',
  'field_rsvp_target',
  'field_organizer',
];

echo "Starting field removal process...\n\n";

foreach ($fields_to_remove as $field_name) {
  echo "Processing: $field_name\n";
  
  // Check if field exists.
  $field_config = FieldConfig::load("node.event.$field_name");
  if (!$field_config) {
    echo "  - Field does not exist, skipping.\n";
    continue;
  }
  
  // Check for data.
  $storage = \Drupal::entityTypeManager()->getStorage('node');
  $query = $storage->getQuery()
    ->accessCheck(FALSE)
    ->condition('type', 'event')
    ->exists($field_name)
    ->range(0, 1);
  $has_data = !empty($query->execute());
  
  if ($has_data) {
    echo "  - WARNING: Field has data. Migration required before removal.\n";
    echo "  - Skipping for now. Please migrate data first.\n";
    continue;
  }
  
  // Delete field instance.
  echo "  - Deleting field instance...\n";
  $field_config->delete();
  
  // Check if storage is used elsewhere.
  $storage_config = FieldStorageConfig::loadByName('node', $field_name);
  if ($storage_config) {
    // Check if used by other bundles.
    $other_instances = \Drupal::entityTypeManager()
      ->getStorage('field_config')
      ->getQuery()
      ->accessCheck(FALSE)
      ->condition('field_name', $field_name)
      ->condition('entity_type', 'node')
      ->execute();
    
    if (empty($other_instances)) {
      echo "  - Deleting field storage...\n";
      $storage_config->delete();
    } else {
      echo "  - Field storage used by other bundles, keeping storage.\n";
    }
  }
  
  echo "  - ✓ Removed successfully.\n\n";
}

echo "Field removal complete.\n";
echo "Please run: ddev drush cr\n";
